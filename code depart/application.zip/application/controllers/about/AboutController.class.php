<?php
class AboutController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {
    return ['message' => 'blablablabla'];
  }
}



 ?>
