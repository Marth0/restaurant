<?php
class ConnexionController
{
  public function httpGetMethod(Http $http, array $queryFields)
  {

  }
  public function httpPostMethod(Http $http, array $formFields)
  {
    new PanierModel{
      $p = createPanier();
    }
  }
}
